"""
Задача №2: найти ближайшую аптеку

API: Поиск по организациям.
https://tech.yandex.ru/maps/geosearch

Документация
------------
О формате запроса:
https://yandex.ru/dev/maps/geosearch/doc/concepts/request.html
О формате ответа:
https://yandex.ru/dev/maps/geosearch/doc/concepts/response_structure_business.html
"""

import requests
from PIL import Image
from io import BytesIO


# Сервер API Поиск по организациям
search_api_server = 'https://search-maps.yandex.ru/v1/'
api_key = 'f0f740c9-e542-47d4-aaa8-9ecdbc77f198'

# Наше местоположение.
# Куйбышев — площадка Лицея Академии Яндекса:
address_ll = '78.334866,55.445356'

# Формируем параметры запроса:
search_params = {
    'apikey': api_key,
    'text': 'аптека',
    'lang': 'ru_RU',
    'll': address_ll,
    'type': 'biz'
}

# Делаем запрос:
response = requests.get(search_api_server, params=search_params)
if not response:
    print('Ошибка выполнения запроса!')
    print(f'HTTP-статус: {response.status_code} - {response.reason}')

# Преобразуем ответ в json-объект:
json_response = response.json()

# Получаем первую найденную организацию:
organization = json_response["features"][0]

# Название организации:
org_name = organization["properties"]["CompanyMetaData"]["name"]

# Адрес организации:
org_address = organization["properties"]["CompanyMetaData"]["address"]

# Получаем координаты ответа:
point = organization["geometry"]["coordinates"]
org_point = f'{point[0]},{point[1]}'
delta = '0.001'

# Собираем параметры для запроса к Static API:
map_params = {
    # Позиционируем карту центром на аптеку:
    'll': org_point,
    'spn': ','.join([delta, delta]),
    'l': 'map',
    # Добавляем для наглядности метку при помощи параметра pm2dgm
    # См. доки https://yandex.ru/dev/maps/staticapi/doc/1.x/dg/concepts/markers.html
    'pt': f'{org_point},pm2dgm'
}

# Static API
map_api_server = 'http://static-maps.yandex.ru/1.x/'

# Запрос:
response = requests.get(map_api_server, params=map_params)

# Посмотрим сформированный URL, используя атрибут url:
print(response.url)

# Выводим карту ответа на экран:
if response:
    Image.open(BytesIO(response.content)).show()
else:
    print('Ошибка выполнения запроса!')
    print(f'HTTP-статус: {response.status_code} - {response.reason}')
