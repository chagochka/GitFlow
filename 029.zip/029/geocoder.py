"""
Набор полезных функций для работы с картами
"""

import requests


GEOCODER_API = 'http://geocode-maps.yandex.ru/1.x/'
API_KEY = '40d1649f-0493-4b70-98ba-98533de7710b'


def geocode(address):
    """Функция собирает словарь-запрос для гео-кодера по адресу объекта"""
    geocoder_params = {
        'apikey': API_KEY,
        'geocode': address,
        'format': 'json'
    }

    # Выполняем запрос.
    response = requests.get(GEOCODER_API, params=geocoder_params)

    if response:
        # Преобразуем ответ в json-объект
        json_response = response.json()
    else:
        raise RuntimeError(
            f'Ошибка выполнения запроса: {GEOCODER_API}'
            f'HTTP-статус: {response.status_code} ({response.reason})'
        )

    # Получаем первый топоним из ответа гео-кодера.
    # Согласно описанию ответа он находится по следующему пути:
    features = json_response["response"]["GeoObjectCollection"]["featureMember"]
    return features[0]["GeoObject"] if features else None


def get_coordinates(address):
    """Функция возвращает координаты объекта по его адресу"""
    toponym = geocode(address)
    if not toponym:
        return None, None

    # Координаты центра топонима:
    toponym_coordinates = toponym["Point"]["pos"]
    # Широта, преобразованная в плавающее число:
    toponym_longitude, toponym_latitude = toponym_coordinates.split(" ")
    return float(toponym_longitude), float(toponym_latitude)


def get_ll_span(address):
    """Функция по адресу объекта возвращает
    параметры для рисования карты вокруг него:
    координаты центра и размеры по ширине и высоте."""
    toponym = geocode(address)
    if not toponym:
        return None, None

    # Координаты центра топонима:
    toponym_coordinates = toponym["Point"]["pos"]
    # Долгота и широта:
    toponym_longitude, toponym_latitude = toponym_coordinates.split(" ")

    # Собираем координаты в параметр ll:
    ll = ','.join([toponym_longitude, toponym_latitude])

    # Рамка вокруг объекта:
    envelope = toponym["boundedBy"]["Envelope"]

    # левая, нижняя, правая и верхняя границы из координат углов:
    l, b = envelope["lowerCorner"].split(' ')
    r, t = envelope["upperCorner"].split(' ')

    # Вычисляем половинные размеры по вертикали и горизонтали:
    dx = abs(float(l) - float(r)) / 2
    dy = abs(float(t) - float(b)) / 2

    # Собираем размеры в параметр span:
    span = f'{dx},{dy}'

    # ll - центр, span - размеры
    return ll, span


def get_nearest_object(point, kind):
    """Функция находит ближайший
    к заданной точке point объект типа kind"""
    ll = f'{point[0]},{point[1]}'

    geocoder_params = {
        'apikey': API_KEY,
        'geocode': ll,
        'format': 'json'}

    if kind:
        geocoder_params['kind'] = kind

    # Выполняем запрос к гео-кодеру, анализируем ответ.
    response = requests.get(GEOCODER_API, params=geocoder_params)
    if not response:
        raise RuntimeError(
            f'Ошибка выполнения запроса: {GEOCODER_API}'
            f'HTTP-статус: {response.status_code} ({response.reason})'
        )

    # Преобразуем ответ в json-объект
    json_response = response.json()

    # Получаем первый топоним из ответа гео-кодера.
    features = json_response["response"]["GeoObjectCollection"]["featureMember"]
    return features[0]["GeoObject"]["name"] if features else None


# Примеры:
print(geocode('Новосибирская область, Куйбышев, 5-й квартал, д. 1'))
print(get_ll_span('Новосибирская область, Куйбышев, 5-й квартал, д. 1'))
print(get_nearest_object((78.334866, 55.445356), kind='street'))
