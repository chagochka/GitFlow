"""
Задача №1: создать поисковый скрипт search.py

Пользователь печатает в командной строке запрос:
python search.py Москва, ул. Ак. Королева, 12

Скрипт находит координаты запрошенного объекта и показывает его на карте.
"""

import sys
import requests
from PIL import Image
from io import BytesIO


# Считываем аргументы командной строки:
toponym_to_find = ' '.join(sys.argv[1:])

geocoder_api_server = 'http://geocode-maps.yandex.ru/1.x/'

geocoder_params = {
    'apikey': '40d1649f-0493-4b70-98ba-98533de7710b',  # Ключ для гео-кодера
    'geocode': toponym_to_find,  # Запрос для гео-кодера
    'format': 'json'  # Формат данных
}

# Делаем запрос к гео-кодеру:
response = requests.get(geocoder_api_server, params=geocoder_params)
if not response:
    print('Ошибка выполнения запроса!')
    print(f'HTTP-статус: {response.status_code} - {response.reason}')

map_api_server = 'http://static-maps.yandex.ru/1.x/'

# Преобразуем ответ в json-объект
json_response = response.json()

# Получаем топоним из ответа гео-кодера:
toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]

# Определяем координаты центра топонима:
toponym_coordinates = toponym["Point"]["pos"]

# Определяем долготу и широту:
longitude, latitude = toponym_coordinates.split(' ')

# Задаём масштаб:
delta = '0.005'

# Создаём параметры для запроса к Static API:
map_params = {
    'll': ','.join([longitude, latitude]),
    'spn': ','.join([delta, delta]),
    'l': 'map'
}

# Делаем запрос к Static API:
response = requests.get(map_api_server, params=map_params)

# Выводим результат запроса:
if response:
    Image.open(BytesIO(response.content)).show()
else:
    print('Ошибка выполнения запроса!')
    print(f'HTTP-статус: {response.status_code} - {response.reason}')


# Попробуйте команду:
# python search.py Новосибирская область, Куйбышев, 5-й квартал, д. 1
